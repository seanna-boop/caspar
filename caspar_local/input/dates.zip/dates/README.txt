period.csv uses ALL data from 2015-recent
period_alt_pre.csv uses the same amount of data points for pre and post (post is the limiting factor)